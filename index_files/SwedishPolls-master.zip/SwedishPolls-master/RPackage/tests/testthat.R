library(testthat)
test_check("SwedishPolls")