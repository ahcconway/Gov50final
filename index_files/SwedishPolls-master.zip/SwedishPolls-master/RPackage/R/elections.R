#' Elections results in Sweden
#'
#' A dataset containing the election results during the period of the Swedish polls.
#'
#' @format A data frame with one row per election and the same variables as in the Polls dataset.
#' 
"elections"
